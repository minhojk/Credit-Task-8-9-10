create Database WapDB
use WapDB
create table Item(
ItemID varchar(30) primary key,
ItemName varchar(30),
Size varchar(30))

create table Agent(
AgentID varchar(30) primary key,
AgentName varchar(30),
Address varchar(30))

create table Orders(
OrderID varchar(30) primary key,
OrderDate Date,
AgentID varchar(30))

create table OrderDetail(
ID varchar(30),
OrderID varchar(30),
ItemID varchar(30),
Quantity INT,
UnitAmount varchar(30))

INSERT INTO Item (ItemID, ItemName, Size)
VALUES
  ('ITM001', 'T-shirt', 'Medium'),
  ('ITM002', 'Jeans', 'Small'),
  ('ITM003', 'Sneakers', 'Large'),
  ('ITM004', 'Sunglasses', 'One Size'),
  ('ITM005', 'Backpack', 'One Size'),
  ('ITM006', 'Sweatshirt', 'Medium'),
  ('ITM007', 'Leggings', 'Small'),
  ('ITM008', 'Socks', 'Large'),
  ('ITM009', 'Jacket', 'Medium'),
  ('ITM010', 'Hat', 'One Size'),
  ('ITM011', 'Shorts', 'Small'),
  ('ITM012', 'Tank top', 'Large'),
  ('ITM013', 'Boots', 'Medium'),
  ('ITM014', 'Dress', 'Small'),
  ('ITM015', 'Pants', 'Large');

INSERT INTO Agent (AgentID, AgentName, Address)
VALUES
  ('AGT001', 'John Smith', '123 Main St'),
  ('AGT002', 'Jane Doe', '456 Elm St'),
  ('AGT003', 'Mike Johnson', '789 Oak St'),
  ('AGT004', 'Emily Davis', '234 Maple Ave'),
  ('AGT005', 'David Lee', '567 Pine St'),
  ('AGT006', 'Sarah Chen', '890 Cedar Blvd'),
  ('AGT007', 'William Kim', '1234 Spruce St'),
  ('AGT008', 'Karen Wong', '5678 Birch Ln'),
  ('AGT009', 'Kevin Brown', '910 Oakwood Dr'),
  ('AGT010', 'Jenny Lee', '111 Pine St'),
  ('AGT011', 'Michael Chen', '222 Maple Ave'),
  ('AGT012', 'Laura Garcia', '333 Elm St'),
  ('AGT013', 'Robert Johnson', '444 Main St'),
  ('AGT014', 'Daniel Kim', '555 Spruce St'),
  ('AGT015', 'Jennifer Davis', '666 Cedar Blvd');

INSERT INTO Orders (OrderID, OrderDate, AgentID)
VALUES
  ('ORD001', '2022-01-01', 'AGT001'),
  ('ORD002', '2022-01-02', 'AGT002'),
  ('ORD003', '2022-01-03', 'AGT003'),
  ('ORD004', '2022-01-04', 'AGT004'),
  ('ORD005', '2022-01-05', 'AGT005'),
  ('ORD006', '2022-01-06', 'AGT006'),
  ('ORD007', '2022-01-07', 'AGT007'),
  ('ORD008', '2022-01-08', 'AGT008'),
  ('ORD009', '2022-01-09', 'AGT009'),
  ('ORD010', '2022-01-10', 'AGT010'),
  ('ORD011', '2022-01-11', 'AGT011'),
  ('ORD012', '2022-01-12', 'AGT012'),
  ('ORD013', '2022-01-13', 'AGT013'),
  ('ORD014', '2022-01-14', 'AGT014'),
  ('ORD015', '2022-01-15', 'AGT015');

INSERT INTO OrderDetail (ID, OrderID, ItemID, Quantity, UnitAmount)
VALUES
  ('AGT001', 'ORD001', 'ITM001', '5', '10.00'),
  ('AGT002', 'ORD001', 'ITM002', '3', '15.00'),
  ('AGT003', 'ORD002', 'ITM003', '2', '20.00'),
  ('AGT004', 'ORD002', 'ITM004', '4', '8.00'),
  ('AGT005', 'ORD003', 'ITM005', '1', '50.00'),
  ('AGT006', 'ORD003', 'ITM006', '2', '25.00'),
  ('AGT007', 'ORD004', 'ITM007', '3', '15.00'),
  ('AGT008', 'ORD004', 'ITM008', '2', '20.00'),
  ('AGT009', 'ORD005', 'ITM009', '1', '100.00'),
  ('AGT0010', 'ORD005', 'ITM010', '3', '30.00'),
  ('AGT0011', 'ORD006', 'ITM011', '2', '25.00'),
  ('AGT0012', 'ORD006', 'ITM012', '1', '50.00'),
  ('AGT0013', 'ORD007', 'ITM013', '4', '10.00'),
  ('AGT0014', 'ORD007', 'ITM014', '2', '20.00'),
  ('AGT0015', 'ORD008', 'ITM015', '1', '75.00');


ALTER TABLE OrderDetail
ADD FOREIGN KEY (OrderID)
REFERENCES Orders(OrderID);

ALTER TABLE OrderDetail
ADD FOREIGN KEY (ItemID)
REFERENCES Item(ItemID);

ALTER TABLE Orders
ADD FOREIGN KEY (AgentID)
REFERENCES Agent(AgentID);

ALTER TABLE OrderDetail
ALTER COLUMN Quantity int;

ALTER TABLE OrderDetail
ADD PRIMARY KEY (ID);

ALTER TABLE OrderDetail
alter column ID varchar(30) NOT NULL;
