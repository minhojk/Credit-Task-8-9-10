CREATE DATABASE Users
use Users
CREATE TABLE tblUser(
UserID varchar(30),
UserName varchar(30),
Password varchar(30),
IsActive bit)

insert into tblUser (UserID, UserName, Password, IsActive)
values
('US1', 'User1', '123', '1'),
('US2', 'User2', '12345', '1');

alter table tblUser
alter column UserID varchar(30) NOT NULL;

alter table tblUser
add primary key (UserID);